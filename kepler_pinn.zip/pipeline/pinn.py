"""
Phase 4 — Physics-Informed Neural Network (TODO: implement).

THIS FILE IS DELIBERATELY A SKELETON.
The architecture is designed; the implementation is the author's work.

Design contract
---------------
- Input: 1D tensor of time values t
- Output: predicted flux F(t)
- Loss:  L_total = L_data + lambda * L_physics
    L_data    = MSE(F_pred, F_obs)
    L_physics = (DeltaF_pred - (Rp/R*)^2)^2     [transit geometry]
- Results are written to the same SQL results table as BLS, with
  method="pinn", so the dashboard can overlay both. Validation =
  pinn.rp_over_rstar vs bls.rp_over_rstar vs NASA archive value.

Uncomment `torch` in requirements.txt when starting this phase.
"""

# import torch
# import torch.nn as nn


# TODO 1: Define TransitNet(nn.Module)
#   - fully connected: 1 -> 64 -> 64 -> 1, tanh activations
#   - forward(t) returns predicted flux


# TODO 2: Implement physics_loss(f_pred, f_obs, r_planet, r_star, lam)
#   - L_data: mean squared error between prediction and observation
#   - L_physics: penalise violation of DeltaF = (Rp/R*)^2
#   - return L_data + lam * L_physics


# TODO 3: Implement train_pinn(time, flux, epochs=5000, lr=1e-3)
#   - convert numpy arrays -> float32 tensors (shape [N, 1])
#   - normalise time to roughly [-1, 1] before feeding the network
#     (tanh nets train poorly on raw day values in the hundreds)
#   - Adam optimiser; standard loop: zero_grad -> forward -> loss ->
#     backward -> step
#   - START with lam=0 (pure data fit), verify the transit shape is
#     learned, THEN increase lam to enforce the physics


# TODO 4: Implement extract_results(model, time) -> dict
#   - same keys as analyze.run_bls() so db.storage.save_result()
#     accepts it unchanged, with method="pinn"


def train_pinn(*args, **kwargs):
    raise NotImplementedError(
        "Phase 4 is yours to build — see the numbered TODOs above."
    )
